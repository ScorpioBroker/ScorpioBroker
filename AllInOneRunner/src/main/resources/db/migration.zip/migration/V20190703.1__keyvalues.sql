ALTER TABLE entity ADD kvdata JSONB;
